export {};

declare global {
  interface Window {
    __user: any;
  }
}
