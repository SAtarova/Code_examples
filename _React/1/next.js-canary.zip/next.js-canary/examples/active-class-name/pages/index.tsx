import Nav from "../components/Nav";

const IndexPage = () => (
  <>
    <Nav />
    <p>Hello, I'm the index page</p>
  </>
);

export default IndexPage;
