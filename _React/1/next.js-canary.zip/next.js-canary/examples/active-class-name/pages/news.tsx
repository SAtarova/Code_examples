import Nav from "../components/Nav";

const News = () => (
  <>
    <Nav />
    <p>Hello, I'm the news page</p>
  </>
);

export default News;
