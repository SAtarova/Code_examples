import styles from "../styles.module.css";

const Home = () => {
  return (
    <div className={styles.hello}>
      <p>Hello World</p>
    </div>
  );
};

export default Home;
