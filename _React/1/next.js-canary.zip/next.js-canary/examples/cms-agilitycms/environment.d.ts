declare namespace NodeJS {
  export interface ProcessEnv {
    readonly AGILITY_CMS_GUID: string;
    readonly AGILITY_CMS_API_FETCH_KEY: string;
  }
}
