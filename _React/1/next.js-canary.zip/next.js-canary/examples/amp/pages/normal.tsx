export default function NormalPage() {
  return <p>I'm just a normal old page, no AMP for me</p>;
}
