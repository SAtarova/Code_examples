export type User = {
  id: number;
  name?: string;
};
