## Stytch with Next.js

You can follow the guide on the [Stytch documentation](https://stytch.com/docs/sdks/javascript-sdk/installation).
