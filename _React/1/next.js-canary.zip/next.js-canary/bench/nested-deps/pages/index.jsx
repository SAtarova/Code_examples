import Comp from '../components/index.jsx'

export default function Home() {
  return <Comp />
}
