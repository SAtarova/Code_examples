export function GET() {
  return Response.json({ name: 'John Doe' })
}

export const dynamic = 'force-dynamic'
