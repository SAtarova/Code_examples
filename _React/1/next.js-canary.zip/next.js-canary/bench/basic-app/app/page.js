import React from 'react'

export default function Page() {
  return <h1>My Page</h1>
}

export const dynamic = 'force-dynamic'
