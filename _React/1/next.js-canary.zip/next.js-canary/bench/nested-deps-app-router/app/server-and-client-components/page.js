import React from 'react'
import Comp from '../../components/index.jsx'
import ClientComponent from './client-component'

export default function Home() {
  return (
    <>
      <Comp />
      <ClientComponent />
    </>
  )
}
